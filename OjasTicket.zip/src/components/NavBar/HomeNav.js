import axios from 'axios';
import { useEffect, useState } from 'react';
import { DropdownButton, Dropdown } from 'react-bootstrap';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import Logo from '../Images/OjasLogo.png'
import logout from '../Images/logout-svgrepo-com@2x.png'
import setting from '../Images/setting.png'
import notification from '../Images/notification.png'
import profie_icon from '../Images/profile_icon.png'
import './HomeNav.css';


function HomeNav() {
    const [flag, setflag] = useState(false)
    const val = useLocation();
    // console.log(val.state);
    const navigate = useNavigate()

    const handleLogout = (e) => {
        setflag(!flag)
        console.log(!flag);
        navigate('/signin')
    }

    const handleLogin = (e) => {
        setflag(false)
        navigate()
    }

    return (
        <div>
            <Navbar style={{ "backgroundColor": "#097ED8" }} variant="light" expand="lg">
                <Container fluid>
                    <Navbar.Brand><img src={Logo} alt='brandlogo' style={{ width: "45px", height: "45px", borderRadius: "10px" }} /></Navbar.Brand>
                    <Navbar.Toggle aria-controls="navbarScroll" />
                    <Navbar.Collapse id="navbarScroll">
                        <Nav
                            className="me-auto my-2 my-lg-0"
                            style={{ maxHeight: '100px' }}
                            navbarScroll
                        >
                            <Nav.Link>
                                <Link to='/'><button type="button" className='btn btn-success'>Home</button></Link>
                            </Nav.Link>
                        </Nav>
                        <Nav>
                            <Nav.Link>
                                <Link to='/signin' > <button type="button" className="button" onClick={handleLogin}>Sign In</button></Link>
                            </Nav.Link>
                            {/* <Nav.Link>
                            <Link to='/signup'><button type="button" className='btn btn-success' >SignUp</button></Link>
                        </Nav.Link> */}

                             <DropdownButton 
                                
                                
                                title='Profile'
                                
                                id='ddb'
                                align="end"

                            >
                                <Dropdown.Item><img src={setting} style={{height:"25px",width:"25px"}}/>Setting</Dropdown.Item>
                                <Dropdown.Item><img src={notification} style={{height:"20px",width:"20px"}}/>Notification</Dropdown.Item>

                                <Dropdown.Divider />

                                <Link to='Logout'><Dropdown.Item onClick={handleLogout}><img src={logout}
                                style={{height:"20px",width:"25px"}} />
                                    Logout
                                </Dropdown.Item></Link>
                                 {/* <Link to='/'><Dropdown.Item onClick={handleLogout}><i class="bi bi-box-arrow-left"></i>Login</Dropdown.Item></Link>  */}
                            </DropdownButton>
                            {/* <div class="dropdown my-2">
                                <Dropdown className='drop1'>
                                    <Dropdown.Toggle className="ddb"  id="dropdown-basic" >
                                        <img src={profie_icon}
                                        style={{height:"25px",width:"25px"}}/>Profile
                                    </Dropdown.Toggle>

                                    <Dropdown.Menu align="end">
                                        <Dropdown.Item href="#/action-1">Setting</Dropdown.Item>
                                        <Dropdown.Item href="#/action-2">Notification</Dropdown.Item>
                                        <Dropdown.Item href="#/action-3">Logout</Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>
                            </div> */}
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>

        </div>

    );
}

export default HomeNav;
